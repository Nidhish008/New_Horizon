# Mental-Health-Check-WebApplication
It's a web-based application. It's a tool that assesses mental health and makes recommendations depending on the user's selection of questions. The questions are shown based on the user's age group. It also offers a function that allows you to take the exam on behalf of a loved one or for yourself.
This was created with HTML, CSS, and JavaScript. To see the project, click on the link.
